package com.cscec.informationcenter.business_subcontract_settlement;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessSubcontractSettlementApplicationTests {

	@Test
	void contextLoads() {
	}

}
