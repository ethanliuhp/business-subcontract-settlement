package com.cscec.informationcenter.business_subcontract_settlement.service.impl;

import com.cscec.informationcenter.business_subcontract_settlement.dao.ContractItemDao;
import com.cscec.informationcenter.business_subcontract_settlement.form.ContractItemForm;
import com.cscec.informationcenter.business_subcontract_settlement.model.ContractItem;
import com.cscec.informationcenter.business_subcontract_settlement.service.ContractItemService;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractItemVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@Service
@Slf4j
public class ContractItemServiceImpl implements ContractItemService {

    @Autowired
    private ContractItemDao contractItemDao;

    @Override
    public String generateCode(String contractId) {
        return contractItemDao.generateCode(contractId);
    }

    @Override
    public void add(ContractItemForm contractItemForm) {
        ContractItem contractItem = new ContractItem();
        BeanUtils.copyProperties(contractItemForm,contractItem);
        contractItemDao.add(contractItem);
    }

    @Override
    public void delete(String contractId,String updateUser) {
        contractItemDao.delete(contractId,updateUser);
    }

    @Override
    public List<ContractItemVO> get(String contractId) {
        List<ContractItem> contractItemList = contractItemDao.get(contractId);
        List<ContractItemVO> contractItemVOList = new ArrayList<>();
        contractItemList.forEach(contractItem -> {
            ContractItemVO contractItemVO = new ContractItemVO();
            BeanUtils.copyProperties(contractItem,contractItemVO);
            contractItemVOList.add(contractItemVO);
        });
        return contractItemVOList;
    }

}
