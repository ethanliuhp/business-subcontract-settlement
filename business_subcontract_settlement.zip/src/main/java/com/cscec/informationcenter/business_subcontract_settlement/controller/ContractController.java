package com.cscec.informationcenter.business_subcontract_settlement.controller;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.cscec.informationcenter.business_subcontract_settlement.form.ContractForm;
import com.cscec.informationcenter.business_subcontract_settlement.service.ContractItemService;
import com.cscec.informationcenter.business_subcontract_settlement.service.ContractService;
import com.cscec.informationcenter.business_subcontract_settlement.utils.ExcelUtil;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractVO;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@RestController
@RequestMapping("/contract")
@CrossOrigin(origins = "*")
@Api(tags = "合同模块-接口集合")
public class ContractController {

    @Autowired
    private ContractService contractService;

    @Autowired
    private ContractItemService contractItemService;

    /**
     * 新增合同信息
     * @param contractForm
     */
    @ApiOperation(value="新增合同信息（id,createUser必传）", notes="传参json")
    @PostMapping("/add")
    //当调用多个服务时，为了保持事务一致性，需要设置失败回滚
    @Transactional(rollbackFor = Exception.class)
    public void add(@RequestBody ContractForm contractForm) {
        contractService.add(contractForm);
    }

    /**
     * 根据id删除合同信息
     * @param idBatch
     */
    @ApiOperation(value="删除合同信息（id,updateUser必传）", notes="传参字符串（拼接待删除合同id用英文逗号,隔开）")
    @PostMapping("/delete")
    @Transactional(rollbackFor = Exception.class)
    public void delete(@RequestParam(name = "idBatch")String idBatch,
                       @RequestParam(name = "updateUser")String updateUser){
        contractService.delete(idBatch,updateUser);
    }

    /**
     *  根据id修改合同信息
     * @param contractForm
     */
    @ApiOperation(value="修改合同信息（id,updateUser必传）", notes="传参json，合同清单列表如果没有变化可以不传")
    @PostMapping("/update")
    @Transactional(rollbackFor = Exception.class)
    public void update(@RequestBody ContractForm contractForm){
        contractService.edit(contractForm);
    }

    @ApiOperation(value="简单查询-分页查询合同列表", notes="无参")
    @GetMapping("/get")
    public PageInfo<ContractVO> get(@RequestParam(name = "pageNo",defaultValue="1")Integer pageNo,
                                    @RequestParam(name = "pageSize",defaultValue="10")Integer pageSize){
        return contractService.get(pageNo, pageSize);
    }

    /**
     *  根据id更正合同信息（更正属于高级权限，更正后无需改变合同状态）
     * @param contractForm
     */
    @ApiOperation(value="更正合同信息（id,updateUser必传）", notes="传参json，合同清单列表如果没有变化可以不传")
    @PostMapping("/correct")
    @Transactional(rollbackFor = Exception.class)
    public void correct(@RequestBody ContractForm contractForm){
        contractService.edit(contractForm);
    }

    @ApiOperation(value = "将所有字典导出到excel",notes = "")
    @GetMapping("/exportExcel")
    public void export(HttpServletResponse response,@RequestParam(name = "idBatch")String idBatch) {
        List<ContractVO> contractVOList = contractService.getByIdBatch(idBatch);

        //TODO 待完善
    }

    //TODO 分包商引用，云筑引用
}
