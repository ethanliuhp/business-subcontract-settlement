package com.cscec.informationcenter.business_subcontract_settlement.service;

import com.cscec.informationcenter.business_subcontract_settlement.form.ContractItemForm;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractItemVO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
public interface ContractItemService {

    /**
     * 生成清单编码
     * @return
     */
    String generateCode(String contractId);

    /**
     *
     * 新增合同清单
     * @param contractItemForm
     */
    void add(ContractItemForm contractItemForm);

    /**
     * 根据合同id删除合同清单列表
     * @param contractId
     * @param updateUser
     */
    void delete(String contractId,String updateUser);

    /**
     * 根据合同id查询合同清单列表
     * @param contractId
     */
    List<ContractItemVO> get(String contractId);
}
