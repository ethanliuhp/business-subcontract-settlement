package com.cscec.informationcenter.business_subcontract_settlement.dao;

import com.cscec.informationcenter.business_subcontract_settlement.model.Contract;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@Mapper
public interface ContractDao {

    /**
     *
     * @return
     */
    String generateCode();

    /**
     *
     * @param contract
     */
    void add(Contract contract);

    /**
     *
     * @param ids
     * @param updateUser
     */
    void delete(String[] ids,String updateUser);

    /**
     *
     * @param contract
     */
    void edit(Contract contract);

    /**
     *
     * @return
     */
    List<Contract> get();

    /**
     *
     * @param contract
     */
    void correct(Contract contract);

    List<Contract> getByIdBatch(String[] ids);
}
