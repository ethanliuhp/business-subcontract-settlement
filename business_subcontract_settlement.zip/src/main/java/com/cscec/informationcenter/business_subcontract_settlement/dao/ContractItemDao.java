package com.cscec.informationcenter.business_subcontract_settlement.dao;

import com.cscec.informationcenter.business_subcontract_settlement.model.ContractItem;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@Mapper
public interface ContractItemDao {

    /**
     *
     * @return
     */
    String generateCode(String contractId);

    /**
     *
     * @param contractItem
     */
    void add(ContractItem contractItem);

    /**
     *
     * @param contractId
     * @param updateUser
     */
    void delete(String contractId,String updateUser);

    /**
     *
     * @param contractIds
     * @param updateUser
     */
    void deleteWithContractIds(String[] contractIds,String updateUser);

    /**
     *
     * @param contractId
     * @return
     */
    List<ContractItem> get(String contractId);
}
