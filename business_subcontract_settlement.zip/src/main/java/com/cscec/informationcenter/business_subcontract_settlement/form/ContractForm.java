package com.cscec.informationcenter.business_subcontract_settlement.form;

import com.cscec.informationcenter.business_subcontract_settlement.model.Contract;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ContractForm extends Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<ContractItemForm> contractItemFormList;
}
