package com.cscec.informationcenter.business_subcontract_settlement.service;

import com.cscec.informationcenter.business_subcontract_settlement.form.ContractForm;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractVO;
import com.github.pagehelper.PageInfo;
import org.checkerframework.checker.units.qual.C;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
public interface ContractService {

    /**
     *
     * @return
     */
    String generateCode();

    /**
     *
     * @param contractForm
     */
    void add(ContractForm contractForm);

    /**
     *
     * @param idBatch
     * @param updateUser
     */
    void delete(String idBatch,String updateUser);

    /**
     *
     * @param contractForm
     */
    void edit(ContractForm contractForm);

    /**
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    PageInfo<ContractVO> get(Integer pageNo,Integer pageSize);

    /**
     *
     * @param contractForm
     */
    void correct(ContractForm contractForm);

    /**
     *
     * @param idBatch
     * @return
     */
    List<ContractVO> getByIdBatch(String idBatch);
}
