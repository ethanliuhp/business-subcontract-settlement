package com.cscec.informationcenter.business_subcontract_settlement.service.impl;

import com.cscec.informationcenter.business_subcontract_settlement.dao.ContractDao;
import com.cscec.informationcenter.business_subcontract_settlement.dao.ContractItemDao;
import com.cscec.informationcenter.business_subcontract_settlement.form.ContractForm;
import com.cscec.informationcenter.business_subcontract_settlement.form.ContractItemForm;
import com.cscec.informationcenter.business_subcontract_settlement.model.Contract;
import com.cscec.informationcenter.business_subcontract_settlement.model.ContractItem;
import com.cscec.informationcenter.business_subcontract_settlement.service.ContractService;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractItemVO;
import com.cscec.informationcenter.business_subcontract_settlement.vo.ContractVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@Service
@Slf4j
public class ContractServiceImpl implements ContractService {

    @Autowired
    private ContractDao contractDao;

    @Autowired
    private ContractItemDao contractItemDao;

    @Override
    public String generateCode() {
        return contractDao.generateCode();
    }

    @Override
    public void add(ContractForm contractForm) {
        Contract contract = new Contract();
        BeanUtils.copyProperties(contractForm,contract);
        String contractCode = contractDao.generateCode();
        if(contractCode.length() <=0){
            throw new NullPointerException("合同编码生成失败");
        }
        contract.setCode(contractCode);
        contractDao.add(contract);
        String contractId = contract.getId();
        List<ContractItemForm> contractItemFormList = contractForm.getContractItemFormList();
        contractItemFormList.forEach(contractItemForm -> {
            ContractItem contractItem = new ContractItem();
            BeanUtils.copyProperties(contractItemForm,contractItem);
            String contractItemCode = contractItemDao.generateCode(contractId);
            if(contractItemCode.length() <= 0){
                throw new NullPointerException("合同清单编码生成失败");
            }
            contractItem.setCode(contractItemCode);
            contractItemDao.add(contractItem);
        });
    }

    @Override
    public void delete(String idBatch,String updateUser) {
        if(idBatch.length()<=0){
            throw new NullPointerException("合同idBatch长度为零或者小于零");
        }
        String[] ids = idBatch.split(",");
        contractDao.delete(ids,updateUser);
        contractItemDao.deleteWithContractIds(ids,updateUser);
    }

    @Override
    public void edit(ContractForm contractForm) {
        Contract contract = new Contract();
        BeanUtils.copyProperties(contractForm,contract);
        contractDao.edit(contract);
        List<ContractItemForm> contractItemFormList = contractForm.getContractItemFormList();
        if(contractItemFormList.size()>0){
            String contractId = contractForm.getId();
            if(contractId == null||contractForm.getUpdateUser()==null){
                throw new NullPointerException("修改合同未填写合同id或合同更新人");
            }
            contractItemDao.delete(contractId,contractForm.getUpdateUser());
            contractItemFormList.forEach(contractItemForm -> {
                ContractItem contractItem = new ContractItem();
                BeanUtils.copyProperties(contractItemForm,contractItem);
                String contractItemCode = contractItemDao.generateCode(contractId);
                if(contractItemCode.length() <= 0){
                    throw new NullPointerException("合同清单编码生成失败");
                }
                contractItem.setCode(contractItemCode);
                contractItemDao.add(contractItem);
            });
        }
    }

    @Override
    public PageInfo<ContractVO> get(Integer pageNo, Integer pageSize) {
        PageHelper.startPage(pageNo,pageSize);
        List<Contract> contractList = contractDao.get();
        PageInfo<Contract> contractPageInfo = new PageInfo<>(contractList);
        List<ContractVO> contractVOList = new ArrayList<>();
        contractList.forEach(contract -> {
            ContractVO contractVO = new ContractVO();
            BeanUtils.copyProperties(contract,contractVO);
            String contractId = contractVO.getId();
            if(contractId.length()<=0){
                throw new NullPointerException("合同id为空，无法查询合同清单");
            }
            List<ContractItem> contractItemList = contractItemDao.get(contractId);
            if(contractItemList.size()>0){
                List<ContractItemVO> contractItemVOList = new ArrayList<>();
                BeanUtils.copyProperties(contractItemList,contractItemVOList);
                contractVO.setContractItemVOList(contractItemVOList);
            }
            contractVOList.add(contractVO);
        });
        PageInfo<ContractVO> contractVOPageInfo = new PageInfo<>();
        BeanUtils.copyProperties(contractPageInfo,contractVOPageInfo);
        contractVOPageInfo.setList(contractVOList);
        return contractVOPageInfo;
    }

    @Override
    public void correct(ContractForm contractForm) {
        Contract contract = new Contract();
        BeanUtils.copyProperties(contractForm,contract);
        contractDao.correct(contract);
        List<ContractItemForm> contractItemFormList = contractForm.getContractItemFormList();
        if(contractItemFormList.size()>0){
            String contractId = contractForm.getId();
            if(contractId == null||contractForm.getUpdateUser()==null){
                throw new NullPointerException("修改合同未填写合同id或合同更新人");
            }
            contractItemDao.delete(contractId,contractForm.getUpdateUser());
            contractItemFormList.forEach(contractItemForm -> {
                ContractItem contractItem = new ContractItem();
                BeanUtils.copyProperties(contractItemForm,contractItem);
                String contractItemCode = contractItemDao.generateCode(contractId);
                if(contractItemCode.length() <= 0){
                    throw new NullPointerException("合同清单编码生成失败");
                }
                contractItem.setCode(contractItemCode);
                contractItemDao.add(contractItem);
            });
        }
    }

    @Override
    public List<ContractVO> getByIdBatch(String idBatch) {
        String[] ids = idBatch.split(",");
        List<Contract> contractList = contractDao.getByIdBatch(ids);
        List<ContractVO> contractVOList = new ArrayList<>();
        contractList.forEach(contract -> {
            ContractVO contractVO = new ContractVO();
            BeanUtils.copyProperties(contract,contractVO);
            String contractId = contractVO.getId();
            if(contractId.length()<=0){
                throw new NullPointerException("合同id为空，无法继续查询合同清单");
            }
            List<ContractItem> contractItemList = contractItemDao.get(contractId);
            if(contractItemList.size()>0){
                List<ContractItemVO> contractItemVOList = new ArrayList<>();
                BeanUtils.copyProperties(contractItemList,contractItemVOList);
                contractVO.setContractItemVOList(contractItemVOList);
            }
            contractVOList.add(contractVO);
        });
        return contractVOList;
    }


}
