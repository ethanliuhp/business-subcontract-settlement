package com.cscec.informationcenter.business_subcontract_settlement.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@AllArgsConstructor
@Getter
public enum BusinessStatus {

    FORWARDED("已交底"),

    EXITED("已退场"),

    FINISHED("已最终结算");

    private String businessStatus;
}
