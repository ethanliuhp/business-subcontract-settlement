package com.cscec.informationcenter.business_subcontract_settlement.model;

import com.cscec.informationcenter.business_subcontract_settlement.constant.ApprovalStatus;
import com.cscec.informationcenter.business_subcontract_settlement.constant.BusinessStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ContractRelativeFiled extends BaseField{

    /**
     * 文件列表
     */
    @ApiModelProperty(value="文件列表，文件字符串(文件名:文件url)中文件之间用英文逗号,隔开")
    private String fileList;

    /**
     * 备注
     */
    @ApiModelProperty(value="备注")
    private String note;

    /**
     * 审批状态
     */
    @ApiModelProperty(value="审批状态")
    private ApprovalStatus approval_status;

    /**
     * 业务状态
     */
    @ApiModelProperty(value="业务状态")
    private BusinessStatus business_status;
}
