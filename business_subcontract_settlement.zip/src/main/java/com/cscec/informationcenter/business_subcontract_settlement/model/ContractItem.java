package com.cscec.informationcenter.business_subcontract_settlement.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.ibatis.type.Alias;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Alias("ContractItem")
public class ContractItem extends BaseField{

    /**
     * 技术要求及项目特征
     */
    @ApiModelProperty(value="技术要求及项目特征")
    private String technicalRequirements;

    /**
     * 核算要素
     */
    @ApiModelProperty(value="核算要素")
    private String accountingElement;

    /**
     * 单位
     */
    @ApiModelProperty(value="单位")
    private String unit;

    /**
     * 合同工程量
     */
    @ApiModelProperty(value="合同工程量")
    private BigDecimal engineeringQuantity;

    /**
     * 合同不含税单价
     */
    @ApiModelProperty(value="合同不含税单价")
    private BigDecimal univalentExcludeTax;

    /**
     * 合同不含税总价
     */
    @ApiModelProperty(value="合同不含税总价")
    private BigDecimal totalExcludeTax;

    /**
     * 含税单价
     */
    @ApiModelProperty(value="含税单价")
    private BigDecimal univalent;

    /**
     * 含税总价
     */
    @ApiModelProperty(value="含税总价")
    private BigDecimal total;

    /**
     * 备注
     */
    @ApiModelProperty(value="备注")
    private String note;

    /**
     * 合同id
     */
    @ApiModelProperty(value="备注")
    private String contractId;

}
