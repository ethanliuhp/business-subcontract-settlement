package com.cscec.informationcenter.business_subcontract_settlement.controller;

import com.cscec.informationcenter.fileapi.service.FileService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/24
 */
@RestController
@RequestMapping("/file")
@CrossOrigin(origins = "*")
@Api(tags = "文件模块-接口集合")
public class FileController {

    @Autowired
    private FileService fileService;

    @PostMapping("/add")
    @ApiOperation("上传文件")
    @ResponseBody
    public String uploadMultipartFile(@RequestParam(name = "file") MultipartFile file,
                                      @RequestParam(name = "createUser")String createUser){
        if(createUser==null||file.isEmpty()){
            throw new NullPointerException("请检查是否未传参创建人或文件");
        }
        String originalFilename = file.getOriginalFilename();
        String url = fileService.uploadFile(createUser, file);
        if(url==null){
            throw new NullPointerException("未返回文件url");
        }
        return originalFilename+url;
    }
}
