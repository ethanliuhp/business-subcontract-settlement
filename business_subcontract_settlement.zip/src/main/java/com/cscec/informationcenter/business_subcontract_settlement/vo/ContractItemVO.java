package com.cscec.informationcenter.business_subcontract_settlement.vo;

import com.cscec.informationcenter.business_subcontract_settlement.model.ContractItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ContractItemVO extends ContractItem implements Serializable {
    private static final long serialVersionUID = 1L;
}
