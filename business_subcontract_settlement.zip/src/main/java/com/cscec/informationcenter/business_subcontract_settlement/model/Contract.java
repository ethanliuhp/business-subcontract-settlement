package com.cscec.informationcenter.business_subcontract_settlement.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class Contract extends ContractRelativeFiled {

    /**
     * 云筑网关联id
     */
    @ApiModelProperty(value="云筑网关联id")
    private String yunzhuId;

    /**
     * 项目id
     */
    @ApiModelProperty(value="项目id")
    private String projectId;

    /**
     * 项目名称
     */
    @ApiModelProperty(value="项目名称")
    private String projectName;

    /**
     * 招标名称
     */
    @ApiModelProperty(value="招标名称")
    private String tenderName;

    /**
     * 招标来源
     */
    @ApiModelProperty(value="招标来源")
    private String tenderOrigin;

    /**
     * 分包合同签订日期
     */
    @ApiModelProperty(value="分包合同签订日期")
    private LocalDate signDate;

    /**
     * 分包商名称
     */
    @ApiModelProperty(value="分包商名称")
    private String subcontractorName;

    /**
     * 分包计划开工日期
     */
    @ApiModelProperty(value="分包计划开工日期")
    private LocalDate startDate;

    /**
     * 分包计划完工日期
     */
    @ApiModelProperty(value="分包计划完工日期")
    private LocalDate endDate;

    /**
     * 总工期
     */
    @ApiModelProperty(value="总工期")
    private LocalDate totalDuration;

    /**
     * 质保金到期日期
     */
    @ApiModelProperty(value="质保金到期日期")
    private LocalDate warrantyExpireDate;

    /**
     * 质保金比例
     */
    @ApiModelProperty(value="质保金比例")
    private BigDecimal warrantyProportion;

    /**
     * 质保金金额
     */
    @ApiModelProperty(value="质保金金额")
    private BigDecimal warranty;

    /**
     * 人名币不含税合同价（所有清单的不含税价格之和）
     */
    @ApiModelProperty(value="人名币不含税合同价（所有清单的不含税价格之和）")
    private BigDecimal rmbExcludeTax;

    /**
     * 美元合同价
     */
    @ApiModelProperty(value="美元合同价")
    private BigDecimal dollar;

    /**
     * 当地合同价
     */
    @ApiModelProperty(value="当地合同价")
    private BigDecimal localPrice;

    /**
     * 税率
     */
    @ApiModelProperty(value="税率")
    private BigDecimal taxRate;

    /**
     * 税金（人民币不含税合同价*税率）
     */
    @ApiModelProperty(value="税金（人民币不含税合同价*税率）")
    private BigDecimal tax;

    /**
     * 人名币含税合同价（人民币不含税合同价+税金）
     */
    @ApiModelProperty(value="人名币含税合同价（人民币不含税合同价+税金）")
    private BigDecimal rmb;

    /**
     * 纳税人识别号
     */
    @ApiModelProperty(value="纳税人识别号")
    private String taxpayerIdentification;

    /**
     * 开户行
     */
    @ApiModelProperty(value="开户行")
    private String bank;

    /**
     * 银行账号
     */
    @ApiModelProperty(value="银行账号")
    private String bankAccount;

    /**
     * 过程支付比例
     */
    @ApiModelProperty(value="过程支付比例")
    private BigDecimal processPaymentRatio;

    /**
     * 最终支付比例
     */
    @ApiModelProperty(value="最终支付比例")
    private BigDecimal finalPaymentRatio;

    /**
     * 保质期付款比
     */
    @ApiModelProperty(value="保质期付款比")
    private BigDecimal shelfPaymentRatio;

    /**
     * 质量考核比例
     */
    @ApiModelProperty(value="质量考核比例")
    private BigDecimal qualityAssessmentRatio;

    /**
     * 安全考核比例
     */
    @ApiModelProperty(value="安全考核比例")
    private BigDecimal safetyAssessmentRatio;

    /**
     * 进度考核比例
     */
    @ApiModelProperty(value="进度考核比例")
    private BigDecimal progressAssessmentRatio;

    /**
     * 分包主要内容
     */
    @ApiModelProperty(value="分包主要内容")
    private String mainContents;

    /**
     * 结算要求
     */
    @ApiModelProperty(value="结算要求")
    private String billingRequirements;

    /**
     * 质量要求
     */
    @ApiModelProperty(value="质量要求")
    private String qualityRequirements;

    /**
     * 安全要求
     */
    @ApiModelProperty(value="安全要求")
    private String safetyRequirements;

    /**
     * 文件列表
     */
    @ApiModelProperty(value="文件列表")
    private String fileList;
}
