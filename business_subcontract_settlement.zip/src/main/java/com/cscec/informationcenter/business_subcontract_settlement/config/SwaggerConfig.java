package com.cscec.informationcenter.business_subcontract_settlement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/1/6
 */
@Configuration
public class SwaggerConfig {

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                //.host("www.cscec3bjc.com:9006/source/api")
                .host("localhost:8082/business_subcontract_settlement/api")
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.cscec.informationcenter"))
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("值班管理系统API")
                .description("内网基址：http://10.11.210.52:8082/business_subcontract_settlement/api,外网基址：http://www.cscec3bjc.com:9006/business_subcontract_settlement/api")
                //.termsOfServiceUrl("http://www.cscec3bjc.com:9006/source/api")//正式地址 http://www.cscec3bjc.com:9006/source/api
                .termsOfServiceUrl("http://localhost:8082/business_subcontract_settlement/api")
                .version("1.0")
                .build();
    }
}
