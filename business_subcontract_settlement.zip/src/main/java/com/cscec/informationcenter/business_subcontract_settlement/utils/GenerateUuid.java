package com.cscec.informationcenter.business_subcontract_settlement.utils;

import java.util.UUID;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/3/13
 */
public class GenerateUuid {

    public static String getUUID32(){
        return UUID.randomUUID().toString().replace("-", "").toLowerCase();
    }

}
