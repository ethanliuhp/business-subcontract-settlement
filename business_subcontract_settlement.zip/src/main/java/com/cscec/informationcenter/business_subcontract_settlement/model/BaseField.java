package com.cscec.informationcenter.business_subcontract_settlement.model;

import com.cscec.informationcenter.business_subcontract_settlement.utils.GenerateUuid;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/20
 */
@Data
public class BaseField {

    /**
     * uuid 32位
     */
    @ApiModelProperty(value="id")
    private String id;

    /**
     * 编码
     */
    @ApiModelProperty(value="编码")
    private String code;

    /**
     * 创建人
     */
    @ApiModelProperty(value="创建人")
    private String createUser;

    /**
     * 更新人
     */
    @ApiModelProperty(value="更新人")
    private String updateUser;

    /**
     * 创建时间
     */
    @ApiModelProperty(value="创建时间")
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value="更新时间")
    private LocalDateTime updateTime;

    /**
     * 名称
     */
    @ApiModelProperty(value="名称")
    private String name;

    /**
     * 自动生成32位uuid
     * @return
     */
    public String getId() {
        return id==null?GenerateUuid.getUUID32():id;
    }
}
