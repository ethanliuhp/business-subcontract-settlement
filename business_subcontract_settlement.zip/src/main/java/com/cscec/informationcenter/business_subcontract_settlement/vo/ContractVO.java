package com.cscec.informationcenter.business_subcontract_settlement.vo;

import com.cscec.informationcenter.business_subcontract_settlement.model.Contract;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/24
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ContractVO extends Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<ContractItemVO> contractItemVOList;
}
