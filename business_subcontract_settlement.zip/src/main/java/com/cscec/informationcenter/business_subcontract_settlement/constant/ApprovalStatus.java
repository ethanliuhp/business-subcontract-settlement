package com.cscec.informationcenter.business_subcontract_settlement.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Created by IntelliJ IDEA.
 * User: o3155
 * Date: 2020/4/23
 */
@Getter
@AllArgsConstructor
public enum ApprovalStatus {

    SAVED("已保存"),

    COMMITTED("已提交"),

    PASS("审批通过"),

    REJECT("审批未通过");

    private String approvalStatus;
}
